# 2024 Sustainable Impact Report

![img-0.jpeg](img-0.jpeg)

hp