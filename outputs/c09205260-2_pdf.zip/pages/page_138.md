hp

2024

Sustainable

Impact Report

# Our Employees

Approximately 58,000 employees worldwide power HP's innovation and perspectives to create breakthrough technologies and transformative solutions that drive our long-term success.

![img-146.jpeg](img-146.jpeg)

We are committed to fostering an inclusive and respectful workplace that attracts, retains, and advances exceptional talent. Through ongoing employee development, comprehensive compensation and benefits; and a focus on health, safety, and well-being; we strive to support our employees to do their best work—while they learn, grow, and feel engaged.

- Introduction
- Sustainable Impact
- Empower Customer Sustainability
- Transform HP's Value Chain

## Advance Societal Impact

Our Mission

Our Goals

Economic Opportunity and Digital/AI Skills

Empowering Communities and Volunteerism

Healthcare

Data

Public Policy

Our Employees

Inclusion at HP

Data

- Appendix

hp.com/sustainableimpact | 139