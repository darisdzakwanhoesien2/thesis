Transform HP's Value Chain | Human Rights Due Diligence | Embedding Responsible Business Conduct

hp

2024

Sustainable

Impact Report

We collaborate, partner, and engage with many industry bodies, memberships, and other organizations. Engagement with partners includes receiving insights and advice, as well as advancing collaborative action on focus areas such as equity, supply chain sustainability, responsible technology, and climate justice. Here are some of our most active partners and collaborations in 2024.

![img-91.jpeg](img-91.jpeg)

![img-92.jpeg](img-92.jpeg)

![img-93.jpeg](img-93.jpeg)

![img-94.jpeg](img-94.jpeg)

![img-95.jpeg](img-95.jpeg)

![img-96.jpeg](img-96.jpeg)

![img-97.jpeg](img-97.jpeg)

![img-98.jpeg](img-98.jpeg)

![img-99.jpeg](img-99.jpeg)

![img-100.jpeg](img-100.jpeg)

![img-101.jpeg](img-101.jpeg)

![img-102.jpeg](img-102.jpeg)

![img-103.jpeg](img-103.jpeg)

![img-104.jpeg](img-104.jpeg)

![img-105.jpeg](img-105.jpeg)

![img-106.jpeg](img-106.jpeg)

![img-107.jpeg](img-107.jpeg)

![img-108.jpeg](img-108.jpeg)

![img-109.jpeg](img-109.jpeg)

![img-110.jpeg](img-110.jpeg)

hp.com/sustainableimpact | 097